// Buffer cache.
//
// The buffer cache is a linked list of buf structures holding
// cached copies of disk block contents.  Caching disk blocks
// in memory reduces the number of disk reads and also provides
// a synchronization point for disk blocks used by multiple processes.
//
// Interface:
// * To get a buffer for a particular disk block, call bread.
// * After changing buffer data, call bwrite to write it to disk.
// * When done with the buffer, call brelse.
// * Do not use the buffer after calling brelse.
// * Only one process at a time can use a buffer,
//     so do not keep them longer than necessary.


#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "riscv.h"
#include "defs.h"
#include "fs.h"
#include "buf.h"

#define NBUCKETS 13

struct {
  struct spinlock lock[NBUCKETS];
  struct buf buf[NBUF];

  // Linked list of all buffers, through prev/next.
  // Sorted by how recently the buffer was used.
  // head.next is most recent, head.prev is least.
  //struct buf head;
  struct buf hashBucket[NBUCKETS];
  struct spinlock steal_lock;
} bcache;

void
binit(void)
{
  struct buf *b;

  //initlock(&bcache.steal_lock,"buffer_steal");

  for(int i = 0 ; i < NBUCKETS ; i++ ){
    initlock(&bcache.lock[i], "bcache");  //为每一个哈希桶初始化锁
    // Create linked list of buffers
    bcache.hashBucket[i].prev = &bcache.hashBucket[i];
    bcache.hashBucket[i].next = &bcache.hashBucket[i];
  }

  for(b = bcache.buf; b < bcache.buf+NBUF; b++){  //为每个哈希桶都分配一些缓存

    int hash_num = hashFunction(b->blockno);
    b->next = bcache.hashBucket[hash_num].next;
    b->prev = &bcache.hashBucket[hash_num];
    initsleeplock(&b->lock, "buffer");
    bcache.hashBucket[hash_num].next->prev = b;
    bcache.hashBucket[hash_num].next = b;

  }

}

// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
static struct buf*
bget(uint dev, uint blockno)
{
  struct buf *b;

  int hash_num = hashFunction(blockno);   //获取哈希值

  acquire(&bcache.lock[hash_num]);

  // Is the block already cached?
  for(b = bcache.hashBucket[hash_num].next; b != &bcache.hashBucket[hash_num]; b = b->next){
    if(b->dev == dev && b->blockno == blockno){     //命中则返回
      b->refcnt++;
      release(&bcache.lock[hash_num]);
      acquiresleep(&b->lock);
      return b;   
    }
  }

  // Not cached.
  // Recycle the least recently used (LRU) unused buffer.
  for(b = bcache.hashBucket[hash_num].prev; b != &bcache.hashBucket[hash_num]; b = b->prev){
    if(b->refcnt == 0) {     //查找当前哈希桶中还有无空闲缓存，有则直接返回
      b->dev = dev;
      b->blockno = blockno;
      b->valid = 0;
      b->refcnt = 1;
      release(&bcache.lock[hash_num]);
      acquiresleep(&b->lock);
      return b;
    }
  }

  // steal
  //acquire(&bcache.steal_lock[hash_num]);
  for(int steal = (hash_num+1)%NBUCKETS ; steal != hash_num ;steal = (steal+1)%NBUCKETS ){   //窃取其他哈希桶中的空闲缓存
    acquire(&bcache.lock[steal]);
    for(b = bcache.hashBucket[steal].prev ; b != &bcache.hashBucket[steal] ; b = b->prev ){
      if(b->refcnt == 0){
        b->dev = dev ;
        b->blockno = blockno ;
        b->valid = 0 ;
        b->refcnt = 1 ;
        b->next->prev = b->prev;    //take the block out
        b->prev->next = b->next;
        release(&bcache.lock[steal]);
        b->next = bcache.hashBucket[hash_num].next;
        b->prev = &bcache.hashBucket[hash_num];
        bcache.hashBucket[hash_num].next->prev = b;
        bcache.hashBucket[hash_num].next = b;
        release(&bcache.lock[hash_num]);
        acquiresleep(&b->lock);
        return b;
      }
    }
    release(&bcache.lock[steal]);
  }
  // release(&bcache.steal_lock);
  // release(&bcache.lock[hash_num]);

  panic("bget: no buffers");
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("bwrite");
  virtio_disk_rw(b, 1);
}

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{

  int hash_num = hashFunction(b->blockno);

  if(!holdingsleep(&b->lock))
    panic("brelse");

  releasesleep(&b->lock);

  acquire(&bcache.lock[hash_num]);
  b->refcnt--;
  if (b->refcnt == 0) {
    // no one is waiting for it.
    b->next->prev = b->prev;
    b->prev->next = b->next;
    b->next = bcache.hashBucket[hash_num].next;
    b->prev = &bcache.hashBucket[hash_num];
    bcache.hashBucket[hash_num].next->prev = b;
    bcache.hashBucket[hash_num].next = b;
  }
  
  release(&bcache.lock[hash_num]);
}

void
bpin(struct buf *b) {
  int hash_num = hashFunction(b->blockno);
  acquire(&bcache.lock[hash_num]);
  b->refcnt++;
  release(&bcache.lock[hash_num]);
}

void
bunpin(struct buf *b) {
  int hash_num = hashFunction(b->blockno);
  acquire(&bcache.lock[hash_num]);
  b->refcnt--;
  release(&bcache.lock[hash_num]);
}


int 
hashFunction(int blockno){
  return blockno%NBUCKETS;
}


