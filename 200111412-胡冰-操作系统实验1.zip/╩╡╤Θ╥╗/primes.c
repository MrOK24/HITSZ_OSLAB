#include "kernel/types.h"
#include "user.h"

void is_prime(){

    int pipe_line[2];    //管道定义
    pipe(pipe_line);

    int status;           //状态

    int prime_num;        //存放当前质数

    if(!read( 0 , &prime_num , 4 )){   //如果不存在质数
        return ;   //返回：结束递归
    }
    else{
        printf("prime %d\n",prime_num);      //打印质数到终端
        if( fork() == 0 ){     //子进程

            close(1);             //关闭文件描述符1（标准输出文件）
            dup(pipe_line[1]);    //重定向:用1指向当前进程的pipeline[1]（即将标准输出描述符1映射到pipeline[1]）
            close(pipe_line[0]);  //关闭旧文件描述符
            close(pipe_line[1]);  //关闭旧文件描述符

            int temp ;

            while(read( 0 , &temp , 4 )){   //继续读取数值
                if( temp % prime_num == 0 ){      //不是质数就跳过
                    continue;
                }
                else{
                    write( 1 , &temp , 4 );   //将不被prime_num整除的数通过管道写入到子进程
                }
            }

        }
        else{

            wait(&status);   //阻塞父进程，等待子进程结束
            
            close(0);         //关闭文件描述符0（标准输入文件）
            dup(pipe_line[0]); //重定向：用0指向当前进程的pipeline[0]（即将标准输入描述符0映射到pipeline[0]）
            close(pipe_line[0]); //关闭旧文件描述符
            close(pipe_line[1]); //关闭旧文件描述符

            is_prime();       //递归调用

        }
    }
}

int main(int argc,char* argv[]){
    int pipeline[2];
    pipe(pipeline);
    int status;

    if(fork()==0){
        close(1);
        dup(pipeline[1]);  //重定向:用1指向pipeline[1]
        close(pipeline[0]); //关闭旧文件描述符
        close(pipeline[1]); //关闭旧文件描述符

        for(int i = 2 ; i < 36 ; i++ ){   //将数值全部写入管道

            write(1,&i,4);

        }

    }
    else{
        wait(&status);    //阻塞父进程，等待子线程结束

        close(0);        
        dup(pipeline[0]);   //重定向
        close(pipeline[0]); //关闭旧文件描述符
        close(pipeline[1]); //关闭旧文件描述符

        is_prime();
    }

    exit(0);

}