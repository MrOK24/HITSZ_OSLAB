#include "kernel/types.h"
#include "user.h"

int main(int argc,char* argv[]){
    
    int pipe1[2],pipe2[2];

    char ping[] = "ping";
    char pong[] = "pong";

    char buff1[1024];  //缓冲区1
    char buff2[1024];  //缓冲区2

    pipe(pipe1);  //管道1传递ping:父进程->子进程
    pipe(pipe2);  //管道2传递pong:子进程->父进程

    if( fork() == 0 ){       //子进程

        close(pipe1[1]);     //关闭管道1写端
        read(pipe1[0],buff1,4);  //读取管道1内信息
        if(strcmp( buff1 , ping ) == 0 )  //判断从管道读出的数据是否为“ping”
        {         
            printf("%d: received ping\n",getpid());  //输出到终端
        }
        close(pipe1[0]);     //读取完成，关闭管道1读端

        close(pipe2[0]);     //关闭管道2读端
        write(pipe2[1],pong,4);   //向管道2内写入信息“pong”
        close(pipe2[1]);     //写入完成，关闭管道2写端

    }
    else{      //父进程

        close(pipe1[0]);   //关闭管道1读端  
        write(pipe1[1],ping,4);  //向管道1中写入数据“ping”
        close(pipe1[1]);     //关闭管道1写端

        close(pipe2[1]);   //关闭管道2写端
        read(pipe2[0],buff2,4);  //从管道2内读取信息
        if(strcmp( buff2 , pong ) == 0 )  //判断从管道读出的数据是否为“pong”
        {
            printf("%d: received pong\n",getpid());  //输出到终端
        }
        close(pipe2[0]);  //关闭管道2读端

    }

    exit(0);

}
