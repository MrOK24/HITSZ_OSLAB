#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/param.h"

int main(int argc,char* argv[]){
    if( argc < 2 ){     //参数数量不对

        printf("Wrong number of parameters!!");
        exit(0);      //退出

    }
    else{

        int status;                  //状态
        char *commmand = argv[1];    //获取待执行指令
        char *argv_temp[MAXARG];     //存放参数
        char buf[1024];              //缓冲区
//printf("%d\n",MAXARG);
        for(int i = 0 ; i < argc - 1 ; i++ ){     //获取待执行命令的参数
            argv_temp[i] = argv[i+1];
        }

        while(read(0,&buf,sizeof(buf))){      //获取来自输入或管道的参数
            argv_temp[argc-1] = &buf[0];      //添加到参数的最后一位
            for(int i = 0 ; i < strlen(buf) ; i++ ){
                if(buf[i]=='\n'){      //每接收一行就执行一次指定的命令（以读到换行符为标志）
                    if(fork()==0){     //开启子进程，执行command
                        argv_temp[argc] = 0 ;   //最后一个参数为0，保障exec（）正确执行
                        buf[i] = '\0';             //避免多输出一个患换行符
                        exec(commmand,argv_temp);
                        exit(0);
                    }
                    else{
                        wait(&status);        //父进程等待子进程结束
                        argv_temp[argc-1] = &buf[i+1];      //获取下一行指令
                        continue;
                    }
                }
            }
        }

    }
    
    exit(0);
}