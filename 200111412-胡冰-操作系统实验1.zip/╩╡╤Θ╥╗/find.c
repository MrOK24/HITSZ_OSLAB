#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"

char* fmtname(char *path)   //格式化文件名，消去文件名前面的"/"
{
    static char buf[DIRSIZ+1];
    char *p;

    for(p=path+strlen(path); p >= path && *p != '/'; p--)
        ;

    p++;  //加回去一个地址

    memmove( buf, p, strlen(p) + 1 );
    return buf;
}

void find(char *path,char *filename){

    char buf[512], *p;
    int fd;
    struct dirent de;
    struct stat st;

    if((fd = open(path, 0)) < 0){    //打开路径下的文件，返回一个文件描述符到fd
        fprintf(2, "ls: cannot open %s\n", path);   //打开失败
        return;
    }

    if(fstat(fd, &st) < 0){     //将文件描述符fd所指的文件状态，复制到结构体st中
        fprintf(2, "ls: cannot stat %s\n", path);    //操作失败
        close(fd);     //关闭
        return;
    }

    switch(st.type){
        case T_FILE:   //文件
            if( strcmp( fmtname(path) , filename ) == 0 ){   //比较是否为待查找的文件
                printf( "%s\n" , path );                     //输出路径
            }
            break;

        case T_DIR:   //目录
            if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
                printf("ls: path too long\n");
                break;
            }
            strcpy(buf, path);
            p = buf+strlen(buf);
            *p++ = '/';
            while(read(fd, &de, sizeof(de)) == sizeof(de)){
                if(de.inum == 0)
                    continue;
                memmove(p, de.name, DIRSIZ);
                p[DIRSIZ] = 0;
                if( strcmp(de.name,".") == 0 || strcmp(de.name,"..") == 0 ){   //跳过“.”和“..”的递归
                    continue;
                }
                find(buf,filename);    //递归调用
            }
            break;
    }

    close(fd);    //关闭文件

}

int main(int argc,char* argv[]){

    if( argc < 3 ){   //参数过少
        printf("Wrong number of parameters!!");
        exit(0);      //退出
    }

    find(argv[1],argv[2]);  //相较于ls多了一个参数
    exit(0);

}